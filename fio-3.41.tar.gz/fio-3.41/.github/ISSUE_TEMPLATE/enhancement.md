---
name: Feature enhancement request
about: Suggest a new fio feature
labels: enhancement

---

**Description of the new feature**
<!-- Please be aware regular fio developers are busy with non-fio work. Because
of this, most requests are only completed if someone from outside the project
contributes the code. -->
